export { default } from "$store/components/ui/LinkTree.tsx";
