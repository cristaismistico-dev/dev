export { default, loader } from "$store/components/ui/CategoryBanner.tsx";
