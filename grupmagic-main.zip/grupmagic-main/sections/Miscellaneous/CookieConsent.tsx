export { default } from "$store/components/ui/CookieConsent.tsx";
