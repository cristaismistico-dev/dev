export { default } from "$store/components/ui/WhatsApp.tsx";
