export { default } from "$store/components/product/ProductDetails.tsx";
