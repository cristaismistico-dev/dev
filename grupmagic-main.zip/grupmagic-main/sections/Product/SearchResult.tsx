export { default } from "$store/components/search/SearchResult.tsx";
