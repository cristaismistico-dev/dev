export { default } from "$store/components/product/ProductShelf.tsx";
