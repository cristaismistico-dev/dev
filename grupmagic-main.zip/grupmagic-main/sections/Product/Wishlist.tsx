export { default } from "$store/components/wishlist/WishlistGallery.tsx";
