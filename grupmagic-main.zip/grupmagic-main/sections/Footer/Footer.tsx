export { default } from "$store/components/footer/Footer.tsx";
