export { default } from "$store/components/header/Header.tsx";
