export const headerHeight = "87px";

export const navbarHeight = "53px";
