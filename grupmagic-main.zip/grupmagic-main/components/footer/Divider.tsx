export default function Divider() {
  return (
    <div class="w-full flex">
      <div class="w-full border-b"></div>
    </div>
  );
}
