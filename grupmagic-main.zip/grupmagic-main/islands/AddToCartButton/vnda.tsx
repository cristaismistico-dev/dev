import Component from "$store/components/product/AddToCartButton/vnda.tsx";
import type { Props } from "$store/components/product/AddToCartButton/vnda.tsx";

function Island(props: Props) {
  return <Component {...props} />;
}

export default Island;
