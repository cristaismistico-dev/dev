import Component from "$store/components/footer/Newsletter.tsx";
import type { Props } from "$store/components/footer/Newsletter.tsx";

function Island(props: Props) {
  return <Component {...props} />;
}

export default Island;
