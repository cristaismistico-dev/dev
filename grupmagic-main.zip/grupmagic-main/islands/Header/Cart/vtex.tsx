import Component from "$store/components/header/Buttons/Cart/vtex.tsx";

function Island() {
  return <Component />;
}

export default Island;
