import Component from "$store/components/header/Buttons/Cart/shopify.tsx";

function Island() {
  return <Component />;
}

export default Island;
