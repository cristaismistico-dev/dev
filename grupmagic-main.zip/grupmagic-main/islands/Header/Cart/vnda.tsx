import Component from "$store/components/header/Buttons/Cart/vnda.tsx";

function Island() {
  return <Component />;
}

export default Island;
