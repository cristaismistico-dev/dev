import Component from "$store/components/header/Buttons/Cart/wake.tsx";

function Island() {
  return <Component />;
}

export default Island;
